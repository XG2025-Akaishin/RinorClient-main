package net.shoreline.client.impl.event.entity.player;

import net.shoreline.client.api.event.Cancelable;
import net.shoreline.client.api.event.StageEvent;

@Cancelable
public class PlayerJumpEvent extends StageEvent {

}
