package net.shoreline.client.impl.command;

import baritone.api.command.ICommand;
import net.shoreline.client.api.command.Command;

/**
 * @author Shoreline
 * @since 1.0
 */
public class BaritoneCommand {
    private ICommand command;
}
