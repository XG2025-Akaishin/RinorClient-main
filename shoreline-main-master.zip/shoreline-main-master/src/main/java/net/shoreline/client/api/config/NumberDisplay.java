package net.shoreline.client.api.config;

/**
 * @author linus
 * @since 1.0
 */
public enum NumberDisplay {
    DEFAULT,
    DEGREES,
    PERCENT
}
