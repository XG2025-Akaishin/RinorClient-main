package net.shoreline.client.api.render;

public enum BoxRender {
    FILL,
    OUTLINE
}
