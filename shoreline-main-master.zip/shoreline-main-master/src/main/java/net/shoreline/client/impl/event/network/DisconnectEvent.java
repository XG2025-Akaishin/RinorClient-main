package net.shoreline.client.impl.event.network;

import net.shoreline.client.api.event.Event;

/**
 * @author linus
 * @since 1.0
 */
public class DisconnectEvent extends Event {

}
