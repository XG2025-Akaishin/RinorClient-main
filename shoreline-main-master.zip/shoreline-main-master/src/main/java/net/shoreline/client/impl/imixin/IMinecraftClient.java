package net.shoreline.client.impl.imixin;

public interface IMinecraftClient {
    void leftClick();

    void rightClick();
}
