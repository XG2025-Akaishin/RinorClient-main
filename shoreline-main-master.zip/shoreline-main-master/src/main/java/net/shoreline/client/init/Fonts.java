package net.shoreline.client.init;

import net.shoreline.client.impl.font.VanillaTextRenderer;

public class Fonts {
    //
    public static final VanillaTextRenderer VANILLA = new VanillaTextRenderer();
}
