package net.shoreline.client.impl.gui.hud;

/**
 * @author linus
 * @since 1.0
 */
public class HudScreen {
    // Render offsets for each corner of the screen.
    private float topLeft, topRight, bottomLeft, bottomRight;
}
