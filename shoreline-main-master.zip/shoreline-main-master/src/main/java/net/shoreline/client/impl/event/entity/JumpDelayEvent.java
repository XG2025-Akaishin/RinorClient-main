package net.shoreline.client.impl.event.entity;

import net.shoreline.client.api.event.Cancelable;
import net.shoreline.client.api.event.Event;

@Cancelable
public class JumpDelayEvent extends Event {

}
