package net.shoreline.client.api;

/**
 * @author linus
 * @since 1.0
 */
public interface Identifiable {
    /**
     * @return
     */
    String getId();
}
